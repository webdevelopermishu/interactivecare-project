    

    


<?php $__env->startSection('page_content'); ?>
<div class="mb-3">
    <h3 class="text-center">Hello Buddy</h3>
</div>
<div class="mb-3">
    <div class="text-center">
        <a href="<?php echo e(route('products')); ?>" class="btn btn-info">Goto Form</a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH M:\Work\laravel\resources\views/dashboard.blade.php ENDPATH**/ ?>