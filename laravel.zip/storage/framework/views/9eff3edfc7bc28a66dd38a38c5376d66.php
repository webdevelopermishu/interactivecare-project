<?php $__env->startSection('page_content'); ?>
<div class="row">
    <div class="col-lg-14">
        <div class="card">
            <div class="card-header"><h4 class="text-center">Product Details</h4></div>
            <div class="card-body text-center">
                <div class="mb-2">
                    <img width="400" src="<?php echo e(asset('uploads/products')); ?>/<?php echo e($product_view->product_image); ?>" alt="">
                </div>
                <div class="mb-2">
                    <h5 class="text-center"><?php echo e($product_view->product_name); ?></h5>
                </div>
                <div class="mb-2">
                    <h5 class="text-center">BDT-<?php echo e($product_view->product_price); ?>Tk.</h5>
                </div>
                <div class="mb-2">
                    <a class="btn btn-info" href="<?php echo e(route('products')); ?>">Back</a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH V:\Work\laravel\resources\views/view_product.blade.php ENDPATH**/ ?>